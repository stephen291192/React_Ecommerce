Project name: React_Ecommerce

Install Node (if not already installed on your machine)

To install node modules type: npm i / npm install

To start the development Server: npm start 
